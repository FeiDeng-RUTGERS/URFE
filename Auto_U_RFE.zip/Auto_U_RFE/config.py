"""config file"""

import numpy as np
import pandas as pd
# from lime import discretize,lime_tabular
from sklearn.metrics import classification_report,f1_score,recall_score,precision_score,balanced_accuracy_score,matthews_corrcoef,roc_auc_score,confusion_matrix,accuracy_score,roc_auc_score
from sklearn.model_selection import StratifiedKFold
from imblearn.metrics import classification_report_imbalanced
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import RFE
from sklearn.preprocessing import label_binarize
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression

from sklearn.linear_model import Lasso
from xgboost import XGBClassifier
import warnings
warnings.filterwarnings('ignore')
import os
random_state = 42

root_path = r"D:\Desktop\AUTO_U_RFE" #root path, can config

data_path = root_path + r"\data\com_patient_sample_mrna.csv"#the path for saving data

data_path_patient = root_path + r'\data\data_clinical_patient.csv'
data_path_sample = root_path + r'\data\data_clinical_sample.csv'
data_path_mRNA = root_path + r'\data\data_RNA_Seq_v2_mRNA_median_all_sample_Zscores.csv'

n_splits=10 # times for cross validation

selected=[150, 100, 50] #target selected features numbers

cycles = 10 #repeat times

record_num = 30000 # can be set according to the shape of data

accuracy_expect = 0.8  #Only models with an accuracy higher than this value are worthy of selection. can be set by user.

#to save the parameters for RFE
LR_param_path = root_path + r'\RFE_param_save\LR'
SVM_param_path = root_path + r'\RFE_param_save\SVM' 
RF_param_path = root_path + r'\RFE_param_save\RF'

#for saving results
result_path = root_path + r"\RFE_results"
output_path =root_path + r"\U_RFE_results"
predict_bing_path = root_path + r'\predict_bing' #saving the classification results for union data set
predict_jiao_path = root_path + r'\predict_jiao' #saving the classification results for intersection data set
finall_union_results_path = root_path + r'\finall_union_results'  #saving the classification results for changed union data sets

RFE_models = ['LR', 'SVM', 'RF'] #base estimators, cannot be changed


#optimaize parameters for different classifiers
DT_params = {
                'min_samples_split':np.arange(2,20,1),
                'min_samples_leaf':np.arange(2,20,1),
                'max_depth':np.arange(2,20,1),
            }
LR_params = {'solver': ['liblinear','newton-cg','lbfgs','sag','saga'],#
              'C':np.arange(0.1,0.2,0.1)
            }
MLP_params = {'hidden_layer_sizes': [(10,),(20,)]
            }
"""
(30,),(40,),(50,),(60,),(70,),(80,),(90,),(100,),
                        (20,10), (20,20), (20,30), (20,40), (20,50), (20,60), (20,70), (20,80), (20,90), (20,100),
                        (30, 10), (30, 20), (30, 30), (30, 40), (30, 50), (30, 60), (30, 70), (30, 80),(30, 90), (30, 100),
                        (40, 10), (40, 20), (40, 30), (40, 40), (40, 50), (40, 60), (40, 70), (40, 80),(40, 90), (40, 100),
                        (50, 10), (50, 20), (50, 30), (50, 40), (50, 50), (50, 60), (50, 70), (50, 80),(50, 90), (50, 100),
                        (60, 10), (60, 20), (60, 30), (60, 40), (60, 50), (60, 60), (60, 70), (60, 80),(60, 90), (60, 100),
                        (70, 10), (70, 20), (70, 30), (70, 40), (70, 50), (70, 60), (70, 70), (70, 80),(70, 90), (70, 100),
                        (80, 10), (80, 20), (80, 30), (80, 40), (80, 50), (80, 60), (80, 70), (80, 80),(80, 90), (80, 100),
                        (90, 10), (90, 20), (90, 30), (90, 40), (90, 50), (90, 60), (90, 70), (90, 80),(90, 90), (90, 100),
                        (100, 10), (100, 20), (100, 30), (100, 40), (100, 50), (100, 60), (100, 70), (100, 80),(100, 90), (100, 100)"""

RF_params = {'n_estimators': np.arange(20,30,10),
              'min_samples_split': np.arange(2,4,1),
              'min_samples_leaf': np.arange(2,4,1),
              'max_depth':np.arange(2,4,1),
            }
SVM_params = {
                'kernel':['rbf','linear','sigmoid'],#
                'C':np.arange(0.1,0.3,0.1)   #[0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1,1.1,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,2.0]
            }
XGB_params = {'n_estimators': np.arange(20,30,10),
              'learning_rate': np.arange(0.1,0.2,0.1),
              'max_depth':np.arange(2,4,1),
            }
