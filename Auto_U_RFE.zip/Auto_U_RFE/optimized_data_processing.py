
#%%
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder

from config import data_path_patient, data_path_sample, data_path_mRNA  # should be set in config file

# Helper Functions
def read_patient_data(file_path):
    try:
        df_patient = pd.read_csv(file_path)
        return df_patient
    except Exception as e:
        print(f"Error reading file {file_path}: {e}")
        return None

def create_labels(df_patient):
    conditions = [
        (df_patient['OS_STATUS'] == '0:LIVING') & (df_patient['PFS_STATUS'] == '0:CENSORED'),
        (df_patient['OS_STATUS'] == '0:LIVING') & (df_patient['PFS_STATUS'] == '1:PROGRESSION'),
        (df_patient['OS_STATUS'] == '1:DECEASED') & (df_patient['PFS_STATUS'] == '0:CENSORED'),
        (df_patient['OS_STATUS'] == '1:DECEASED') & (df_patient['PFS_STATUS'] == '1:PROGRESSION'),
        (df_patient['OS_STATUS'] == '7:LIVING') & (df_patient['PFS_STATUS'] == '7:LIVING')
    ]
    choices = [1, 2, 3, 4, 7]
    df_patient['label'] = np.select(conditions, choices, default=0)
    return df_patient

def preprocess_features(df_patient):
    df_patient = df_patient.drop(['OS_STATUS', 'PFS_STATUS'], axis=1)
    num_features = df_patient[['AGE', 'WEIGHT','label']]
    obj_features = df_patient.drop(['PATIENT_ID','label', 'AGE', 'WEIGHT'], axis=1)
    return num_features, obj_features

def encode_label_features(obj_features):
    le = LabelEncoder()
    for col in obj_features.columns:
        obj_features[col] = le.fit_transform(obj_features[col].astype(str)) + 1
        obj_features[col] = obj_features[col].replace(max(obj_features[col]), np.nan)
    return obj_features

def one_hot_encode_features(obj_features):
    features = pd.get_dummies(obj_features, columns=obj_features.columns)
    one_hot_features = features.replace({True: 1, False: 0})
    return one_hot_features

def convert_to_float(num_features):
    for col in num_features.columns:
        num_features[col] = pd.to_numeric(num_features[col], errors='coerce')
    return num_features

def handle_missing_values(df):
    for col in df.columns:
        df[col] = df[col].fillna(df[col].median())
    return df

def delete_sample_without_label(obj_data, to_drop):
    final_data=final_data.drop(to_drop, axis=1)
    return final_data

def set_pd_columns(original_pd):
    original_pd = original_pd.reset_index(drop=True)
    new_columns = original_pd.iloc[0]
    original_pd.columns = new_columns
    original_pd = original_pd.drop(0)
    original_pd= original_pd.reset_index(drop=True)
    return original_pd



def preprocess_sample_data(file_path, num_feature_names):
    try:
        df_sample = pd.read_csv(file_path)
        sample_index = pd.DataFrame(df_sample,columns=['PATIENT_ID']) 

        # num_features = df_sample[num_feature_names]
        obj= df_sample.drop(num_feature_names, axis=1)
        obj_features = obj.drop(['PATIENT_ID'], axis=1)
        
        encoded_obj_features = encode_label_features(obj_features)
        one_hot_encoded_features = one_hot_encode_features(encoded_obj_features)
        # converted_num_features = convert_to_float(num_features)

        # final_features = pd.concat([one_hot_encoded_features, converted_num_features], axis=1)
        final_features = handle_missing_values(one_hot_encoded_features)
        final_features = pd.concat([sample_index, final_features], axis=1)

        return final_features
    except Exception as e:
        print(f"Error processing sample data: {e}")
        return None



################################################################################################################################################

# Main Processing

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------
'''
process data_RNA_Seq_v2_mRNA_median_all_sample_Zscores.csv
input：data_RNA_Seq_v2_mRNA_median_all_sample_Zscores.csv

1.change the columns name of data_RNA_Seq_v2_mRNA_median_all_sample_Zscores.csv(Remove last three characters, for example: from TCGA-AG-A02X-01 to TCGA-AG-A02X)
2.delete the samples without label in df_RNA and patient

output:Remove_duplicate_samples_mRNA.csv
'''
df_RNA=pd.read_csv(data_path_mRNA)
df_RNA=df_RNA.rename(columns={'Hugo_Symbol':'PATIENT_ID'})

#change the columns name of data_RNA_Seq_v2_mRNA_median_all_sample_Zscores.csv(Remove last three characters, for example: from TCGA-AG-A02X-01 to TCGA-AG-A02X)

name=df_RNA.columns
del_index_name=[]
for i in range(len(name)):  #
    if i<=1:
        del_index_name.append(name[i])

    else:
        del_index_name.append(name[i][0:-3])

df_RNA.columns=del_index_name

to_drop_mRNA = ['Entrez_Gene_Id', 'TCGA-5M-AAT5', 'TCGA-5M-AATA', 'TCGA-F5-6810']
final_mRNA =df_RNA.drop(to_drop_mRNA, axis=1)
final_mRNA.to_csv(r'.\data\Remove_duplicate_samples_mRNA.csv',index=False)

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------
'''
process data_clinical_patient.csv

input：data_clinical_patient.csv

1. Only keep those features that need to be used, and abbreviate the name of the feature
2. get the final label (1,2,3,4) based on 'OS_STATUS and 'PFS_STATUS'
3. one-hot encoding process 
4. delete the samples without label

output: Remove_patient_data.csv
'''

df_patient = read_patient_data(data_path_patient)
patient_list=['PATIENT_ID','AGE','SEX','AJCC_PATHOLOGIC_TUMOR_STAGE','ETHNICITY','ICD_O_3_SITE','PATH_M_STAGE','PATH_N_STAGE','PATH_T_STAGE','RACE','RADIATION_THERAPY','WEIGHT','NEW_TUMOR_EVENT_AFTER_INITIAL_TREATMENT','OS_STATUS','PFS_STATUS']

df_patient = df_patient.loc[:, df_patient.columns.isin(patient_list)]

#Abbreviate feature names that are too long
df_patient=df_patient.rename(columns={'AJCC_PATHOLOGIC_TUMOR_STAGE':'APTS','ETHNICITY':'ETHNI','ICD_O_3_SITE':'ICDO3S','RADIATION_THERAPY':'RT','NEW_TUMOR_EVENT_AFTER_INITIAL_TREATMENT':'NTEAIT'})  

if df_patient is not None:
    df_patient = create_labels(df_patient) 
    patient_index=pd.DataFrame(df_patient,columns=['PATIENT_ID']) 
    num_features, obj_features = preprocess_features(df_patient) 
    encoded_obj_features = encode_label_features(obj_features) 
    one_hot_encoded_features = one_hot_encode_features(encoded_obj_features) 
    converted_num_features = convert_to_float(num_features) 
    final_features = pd.concat([one_hot_encoded_features, converted_num_features], axis=1) 
    final_features = handle_missing_values(final_features) 
    final_features = pd.concat([patient_index, final_features], axis=1) 

to_drop_patient = ['TCGA-5M-AAT5','TCGA-5M-AATA','TCGA-F5-6810','TCGA-AA-3558','TCGA-AF-2689']
final_patients = final_features[~final_features['PATIENT_ID'].isin(to_drop_patient)] #594*61

final_patients = final_patients.T
final_patients= final_patients.reset_index()
final_patients= final_patients.reset_index().rename(columns={'index': 'PATIENT_ID'}) #62*591

final_patients.to_csv(r'.\data\Remove_patient_data.csv',index=False) # 60*591

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------
'''
process data_clinical_sample.csv

input：data_clinical_sample.csv
1. one-hot encoding process 
2. delete the samples without label

output: Remove_sample_data.csv；
#--------------------------------------------------------1.one-hot encoding process  ----------------------------------------------------------------------------------------------
#-------------------------------------------------------2. delete the samples without label  ----------------------------------------------------------------------------------------------
'''

num_feature_names = ['AS']
sample_data = preprocess_sample_data(data_path_sample, num_feature_names) 

to_drop_samples = ['TCGA-5M-AAT5', 'TCGA-5M-AATA', 'TCGA-F5-6810', 'TCGA-AA-3558', 'TCGA-AF-2689']
final_samples = sample_data[~sample_data['PATIENT_ID'].isin(to_drop_patient)]

final_samples = final_samples.T
final_samples = final_samples.reset_index()
final_samples = final_samples.reset_index().rename(columns={'index': 'PATIENT_ID'}) #167*590

final_samples.to_csv(r'.\data\Remove_sample_data.csv',index=False)

#########################################################################Merging three datasets########################################################################################
'''
    input: final_patients, final_samples, final_mRNA
    output:com_patient_sample_mrna (save as com_patient_sample_mrna.csv)
'''

final_patients = set_pd_columns(final_patients)
#final_patients = final_patients.reset_index(drop=True)
#new_columns = final_patients.iloc[0]
#final_patients.columns = new_columns
#final_patients = final_patients.drop(0)
#final_patients= final_patients.reset_index(drop=True)

final_samples = set_pd_columns(final_samples)
#final_samples = final_samples.reset_index(drop=True)
#new_columns = final_samples.iloc[0]
#final_samples.columns = new_columns
#final_samples = final_samples.drop(0)
#final_samples= final_samples.reset_index(drop=True)

common_columns = [col for col in final_patients.columns if col in final_samples.columns and col in final_mRNA.columns]
#Join DataFrame row by row
com_patient_sample_mrna = pd.concat([final_patients[common_columns], final_samples[common_columns], final_mRNA[common_columns]], axis=0, join='outer')

com_patient_sample_mrna = com_patient_sample_mrna.rename(columns={'PATIENT_ID':'P_ID'})
com_patient_sample_mrna = com_patient_sample_mrna.dropna()

com_patient_sample_mrna.to_csv(r'.\data\com_patient_sample_mrna.csv',index=False)

##############################################################################################################################
#give the feature and label for follow-up processing based on the preprocessed data---------------------------------------------------------

data = pd.read_csv(r'.\data\com_patient_sample_mrna.csv', header=None, index_col=0)
data=data.T
data = data.dropna(axis=1, how='any')
data=data.drop(['P_ID'],axis=1)
data['label']=pd.to_numeric(data['label'],errors='coerce')
data=pd.DataFrame(data,dtype=np.float64)

feature=data.drop(['label'],axis=1)
label=data['label'].values
label=np.array(label)-1

feature.to_csv(r'.\data\feature_17720.csv')

