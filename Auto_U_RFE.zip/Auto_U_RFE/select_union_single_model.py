from config import *
from create_folder import create_folder
from wanggexunyou import wange
"""
    Three base estimators ('LR', 'SVM', 'RF') are used separately in the RFE framework
    Return the names of all features selected
    ※ p is the target number of features, the process of feature selection starts with a large step size (because the initial number of features is very large) and becomes smaller afterwards. After the number of features is reduced to 200, the number of features is reduced by 10 each time, and the target number of features is also a multiple of 10, so the judgment conditions do not take into account the case where the first digit of p is not 0. For example, p=28, 36, etc.

"""

def train_and_save_model(estimator, xtrain, ytrain, param_path, p):
    create_folder(param_path)
    rfe_train = xtrain
    d = 0
    du = 0
    j = 0
    while rfe_train.shape[1] > p:
        #print("{} is using for the {}th times".format(estimator, j+1))
        #print("the current number of features is {}".format(rfe_train.shape[1]))

        if isinstance(estimator, LogisticRegression): 
            model, model_param = wange.LR_wange(rbf=estimator, n_splits=n_splits, x_train=rfe_train, y_train=ytrain)
        if isinstance(estimator, SVC): 
            model, model_param = wange.SVM_wange(rbf=estimator, n_splits=n_splits, x_train=rfe_train, y_train=ytrain)
        if isinstance(estimator, RandomForestClassifier): 
            model, model_param = wange.RF_wange(rbf=estimator, n_splits=n_splits, x_train=rfe_train, y_train=ytrain) 
        d += 1
        du += 1
        j += 1

        #save parameters
        save_param = np.zeros((1, len(model_param)), dtype=object)
        for i, param_key in enumerate(model_param.keys()):
            save_param[0, i] = model_param[param_key]
        save_param = pd.DataFrame(save_param, columns=model_param.keys())
        save_param.to_csv(f'{param_path}/{j}_{d}_save_rfe_{estimator.__class__.__name__}_param.csv', index=False)

        #If the number of features is above 5200
        if rfe_train.shape[1] - 5000 > 200:

            #The deletion step is set to 5000 before the number of features is reduced to 200.
            rfe_model = RFE(estimator=model, step=5000, n_features_to_select=rfe_train.shape[1] - 5000)  
            ref = rfe_model.fit(rfe_train, ytrain)
            all_name = rfe_train.columns.values.tolist()
            select_name_index = ref.get_support(indices=True)
            select_name = [all_name[t] for t in select_name_index]
            rfe_train = pd.DataFrame(xtrain, columns=select_name)
            if rfe_train.shape[1] - 5000 < 200:
                d = 99#99 rounds of feature deletion have been performed.
                du = 0

        #If the number of features is between 200 and 5200
        if rfe_train.shape[1]-5000<=200 and rfe_train.shape[1]>201 and du!=0:
            #Number of features reduced to 200
            rfe_model = RFE(estimator=model, step=5000, n_features_to_select=200) 
            ref = rfe_model.fit(rfe_train, ytrain)
            all_name = rfe_train.columns.values.tolist()
            select_name_index = ref.get_support(indices=True)
            select_name = []
            for t in select_name_index:
                select_name.append(all_name[t])
            rfe_train = pd.DataFrame(xtrain, columns=select_name)
            d = 199 #199 rounds of feature deletion have been performed.
            tu=0

        #If the number of features is below 200
        if rfe_train.shape[1] <= 200:
            tu = tu + 1
            #Determine whether the target number of features has been reached
            if tu > 1.1 and rfe_train.shape[1] - 10 >= p:  
                rfe_model = RFE(estimator=model, step=10, n_features_to_select=rfe_train.shape[1] - 10) ##The step size for each feature deletion is set to 10

                ref = rfe_model.fit(rfe_train, ytrain)
                all_name = rfe_train.columns.values.tolist()
                select_name_index = ref.get_support(indices=True)
                select_name = [all_name[t] for t in select_name_index]
                rfe_train = pd.DataFrame(xtrain, columns=select_name)

    return rfe_train.columns


def selected_bing_feature_LR(xtrain, ytrain, p):
    LR_RFE = LogisticRegression(random_state=random_state)
    param_path = LR_param_path
    return train_and_save_model(LR_RFE, xtrain, ytrain, param_path, p=p)


def selected_bing_feature_SVM(xtrain, ytrain, p):
    SVM_RFE = SVC(random_state=random_state)
    param_path = SVM_param_path 
    return train_and_save_model(SVM_RFE, xtrain, ytrain, param_path, p=p)


def selected_bing_feature_RF(xtrain, ytrain, p):
    RF_RFE = RandomForestClassifier(random_state=random_state)
    param_path = RF_param_path 
    return train_and_save_model(RF_RFE, xtrain, ytrain, param_path, p=p)
