from config import *
"""
Input parameters:

    X: Feature data of the training set.
    y: Label data of the training set.
    T: Feature data of the test set.
Return values:

    train_pred: matrix of prediction results on the training set, each column represents the prediction result of a base model on the training set.
    test_pred_two: matrix of prediction results on the test set, each column represents the prediction results of one base model on the test set. Each row of this matrix represents multiple prediction results for one sample.

Method Flow:
Convert the input data into a NumPy array.
Divide the training set into n_splits folds using Stratified K-Fold cross validation.
For each base model:
Fit the model on the training set for each fold.
Make predictions on the validation set and get the predictions from the validation set.
Perform prediction on the test set to get the prediction results of the test set.
Save the predictions from the validation set in the corresponding columns of the train_pred matrix.
Save the prediction results on the test set in the corresponding columns of the test_pred_two matrix.
For multiple prediction results on the test set, find the category with the most occurrences in each row as the final test set prediction.
Ultimately, train_pred contains the prediction results for each base model on the training set, while test_pred_two contains the multiple prediction results for each base model on the test set.

"""

class Create_ensemble(object):    
    def __init__(self, n_splits, base_models):
        self.n_splits = n_splits
        self.base_models = base_models
    def predict(self, X, y, T):
        X = np.array(X)
        y = np.array(y)
        T = np.array(T)
        folds = list(StratifiedKFold(n_splits=self.n_splits, shuffle=True,random_state=random_state).split(X, y))
        train_pred = np.zeros((X.shape[0], len(self.base_models)))
        test_pred = np.zeros((T.shape[0], self.n_splits))
        test_pred_two= np.zeros((T.shape[0], len(self.base_models)))
        test_col = 0
        for i, clf in enumerate(self.base_models):
            for j, (train_idx, valid_idx) in enumerate(folds):
                X_train = X[train_idx]
                Y_train = y[train_idx]
                X_valid = X[valid_idx]
                Y_valid = y[valid_idx]

                clf.fit(X_train, Y_train)

                valid_pred = clf.predict(X_valid) 
                train_pred[valid_idx, i] = valid_pred  
                test_pred[:,test_col]= clf.predict(T)  
                test_col+=1

            tpred_weight_two = pd.DataFrame(test_pred)  
            final_tpred_weight_two = tpred_weight_two.mode(axis=1)
            test_precict_two = final_tpred_weight_two[0]

            test_pred_two[:,i]=np.array(test_precict_two)

        return train_pred, test_pred_two