from config import *
from create_folder import create_folder
"""to save classified results and selected features information"""

def save_report(y, y_pred, p, j, type, RFE_model, path):
    report = classification_report(y, y_pred, output_dict=True)
    df_report = pd.DataFrame(report).transpose()
    report_path = path + r'\selected_feature_num_{}\{}\report'.format(p, type)
    create_folder(report_path)
    df_report.to_csv(report_path + r'\{}_{}_report_result.csv'.format(RFE_model, j), index=True)

    confusion_matrix_ = confusion_matrix(y, y_pred)
    confusion_matrix_ = pd.DataFrame(confusion_matrix_).transpose()
    confusion_matrix_path = path + r'\selected_feature_num_{}\{}\matrix'.format(p, type)
    create_folder(confusion_matrix_path)
    confusion_matrix_.to_csv(confusion_matrix_path + r'\{}_{}_matrix_result.csv'.format(RFE_model, j), index=True)

    imbalanced_report = classification_report_imbalanced(y, y_pred, output_dict=True)
    imbalanced_report = pd.DataFrame(imbalanced_report).transpose()
    imbalanced_report_path = path + r'\selected_feature_num_{}\{}\imbalanced_report'.format(p, type)
    create_folder(imbalanced_report_path)
    imbalanced_report.to_csv(imbalanced_report_path + r'\{}_{}_imbalanced_report.csv'.format(RFE_model, j), index=True)

def save_info(p, j, RFE_model, train_selected_feature_name, result_path):
    # save p
    save_weidu = pd.DataFrame({'selected feature number': [len(train_selected_feature_name)]})
    weidu_path = result_path + r'\selected_feature_num_{}\selected_feature_name'.format(p)
    create_folder(weidu_path)
    save_weidu.to_csv(weidu_path + r'\save_weidu.csv',index=False)
    
    # save features names
    score_selected_feature_name = pd.DataFrame({'score_selected_feature_name': train_selected_feature_name})
    selected_feature_name_path = result_path + r'\selected_feature_num_{}\selected_feature_name'.format(p)
    create_folder(selected_feature_name_path)
    score_selected_feature_name.to_csv(selected_feature_name_path + r'\{}_{}_score_selected_feature_name.csv'.format( j,RFE_model), index=False)


def save_union_report(y, y_pred, p, j, feature_num, type, predict_model, path):
    report = classification_report(y, y_pred, output_dict=True)
    df_report = pd.DataFrame(report).transpose()
    report_path = path + r'\{}\report'.format(type)
    create_folder(report_path)
    df_report.to_csv(report_path + r'\{}_{}_{}_report_result.csv'.format(predict_model, j, feature_num), index=True)

    confusion_matrix_ = confusion_matrix(y, y_pred)
    confusion_matrix_ = pd.DataFrame(confusion_matrix_).transpose()
    confusion_matrix_path = path + r'\{}\matrix'.format(type)
    create_folder(confusion_matrix_path)
    confusion_matrix_.to_csv(confusion_matrix_path + r'\{}_{}_{}_matrix_result.csv'.format(predict_model, j, feature_num), index=True)

    imbalanced_report = classification_report_imbalanced(y, y_pred, output_dict=True)
    imbalanced_report = pd.DataFrame(imbalanced_report).transpose()
    imbalanced_report_path = path + r'\{}\imbalanced_report'.format(type)
    create_folder(imbalanced_report_path)
    imbalanced_report.to_csv(imbalanced_report_path + r'\{}_{}_{}_imbalanced_report.csv'.format(predict_model, j, feature_num), index=True)