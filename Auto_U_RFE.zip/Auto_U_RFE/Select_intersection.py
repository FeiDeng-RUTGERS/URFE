from config import *
import glob
"""
        #get the union and intersection feature sets with the select_intersection function in Select_intersection.py, 
        #based on three subsets (the target feature number is p, the repeat times is j) 
        #save them as csv files and return the set names, respectively.
"""
def read_csv_file(file_path):
    return pd.read_csv(file_path, index_col=0, header=0)

def select_intersection(select_feature, repet_number):
    """
    get the union and intersection feature set
    """
    path = result_path + r'\selected_feature_num_{}\selected_feature_name'.format(select_feature) 
    files = glob.glob(path + '\{}_*_score_selected_feature_name.csv'.format(repet_number)) 

    # Read all csv files using list comprehension
    data_frames = [read_csv_file(file) for file in files]

    feature_name_bing = pd.concat(data_frames, axis=1, join='outer') #union set
    feature_name_jiao = pd.concat(data_frames, axis=1, join='inner') #intersection set

    feature_name_bing.to_csv(path + r'\{}_union_feature_name.csv'.format(repet_number))
    feature_name_jiao.to_csv(path + r'\{}_intersect_feature_name.csv'.format(repet_number))

    return feature_name_bing, feature_name_jiao

def prepare_for_URFE(p):
    '''
    Read the saved results 10 times to generate the joint basic feature set and the feature set to be added to prepare for URFE
         base_features: Union of 10 intersections
         await_union_features: Union of all unions
         ready_union_features: Features excluded from the union basic set and already sorted
    '''
    path = result_path + r'\selected_feature_num_{}\selected_feature_name'.format(p) 
    bing_files = glob.glob(path + r'\*_union_feature_name.csv')
    jiao_files = glob.glob(path + r'\*_intersect_feature_name.csv')

    # Read all csv files using list comprehension

    jiao_data_frames = [read_csv_file(file) for file in jiao_files]
    base_features = pd.concat(jiao_data_frames, axis=1, join='outer') #union set

    bing_data_frames = [read_csv_file(file) for file in bing_files]
    await_union_features = pd.concat(bing_data_frames, axis=0)

    feature_counts = await_union_features.index.value_counts()
    sorted_features = feature_counts.sort_values(ascending=False)
    sorted_df = pd.DataFrame(index=sorted_features.index)
    mask = sorted_df.index.isin(base_features.index)
    ready_union_features = sorted_df[~mask]  

    return  base_features, ready_union_features

def URFE(base_features, ready_union_features, n):
    """
        completion_unioned_features: Get the final union feature set by adding features to the basic intersection feature set
    """

    selected_indices = ready_union_features.index[:n]
    completion_unioned_features = pd.concat([pd.DataFrame(base_features), pd.DataFrame(selected_indices)])

    return completion_unioned_features



