

run at terminal:        .\venv\Scripts\activate

then run:               python main.py