from config import *
from Create_Ensemble import Create_ensemble
from create_folder import create_folder
from save_report import save_report, save_union_report
from wanggexunyou.wange import *
#from wange import *
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import classification_report, f1_score, recall_score, precision_score, confusion_matrix
from sklearn.metrics import matthews_corrcoef

from mlxtend.classifier import StackingCVClassifier

from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, AdaBoostClassifier, ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.model_selection import cross_val_score, StratifiedKFold, train_test_split, cross_validate
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from xgboost import XGBClassifier
from sklearn.naive_bayes import GaussianNB
from keras.layers import Dense, Dropout
from keras.models import Sequential
from sklearn.multiclass import OneVsOneClassifier

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import label_binarize


import numpy as np
import pandas as pd



"""Parameter optimization, prediction using classifier and saving results"""

def RF_predict(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest):
    print('-------------------------------------------------------Parameter optimization for RF--------------------------------------------------')

    rf_model = RandomForestClassifier(random_state=random_state)  #take RF as classifier
    # call the function of wange.RF_wange (Grid optimization) to get the best parameters for the classifier
    rdf, rdf_param = RF_wange(rbf=rf_model, n_splits=n_splits, x_train=rfe_xtrain_bing, y_train=ytrain) #rdf:model rdf_param:best parameters
    #print("the best parameters：")
    #print(rdf_param)

    # base_models=[lr_model]
    base_models = [rdf]

    # creat Lgb_stack, an object of Create_ensemble , then call predict function to get the predict results with the base_model
    Lgb_stack = Create_ensemble(n_splits = n_splits, base_models = base_models) # n_splits folds cross-validation
    train_pred, y_pred= Lgb_stack.predict(rfe_xtrain_bing, ytrain, rfe_xtest_bing) # get the predict results for training set and testing set, respectively

    labels = [1,2,3,4]
    y_test_1 = label_binarize(ytest, classes=labels)
    y_preds = label_binarize(y_pred, classes=labels)

    score_weighted = np.zeros((3, 13), dtype=object)
    #get the best parameters
    score_weighted[0, :4] = [rdf_param['n_estimators'], rdf_param['min_samples_split'], rdf_param['min_samples_leaf'], rdf_param['max_depth']]

    # calculate the performance metrics
    metrics = {
        'accuracy': accuracy_score(ytest, y_pred),
        'precision_weighted': precision_score(ytest, y_pred, average='weighted'),
        'recall_weighted': recall_score(ytest, y_pred, average='weighted'),
        'F1_weighted': f1_score(ytest, y_pred, average='weighted'),
        'precision_macro': precision_score(ytest, y_pred, average='macro'),
        'recall_macro': recall_score(ytest, y_pred, average='macro'),
        'F1_macro': f1_score(ytest, y_pred, average='macro'),
        'balanced_accuracy': balanced_accuracy_score(ytest, y_pred),
        'matthews_corrcoef': matthews_corrcoef(ytest, y_pred),
        #'roc_auc': roc_auc_score(y_test_1, y_preds)
    } 

    score_weighted[0, 4:] = list(metrics.values())

    # change to DataFrame
    score_columns = ['n_estimators', 'min_samples_split', 'min_samples_leaf', 'max_depth'] + list(metrics.keys())
    score_weighted = pd.DataFrame(score_weighted, columns=score_columns)

    
    #print(classification_report(ytest, y_pred))
    #print(confusion_matrix(ytest, y_pred))
    #print('------------------------------------------------------------------------------------------')

    return score_weighted, train_pred, y_pred

def RF_predict_and_save(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest, RFE_model, p, j, result_path):
    
    #call RF_predict to get a optimized model and get the predict results and performance metrics
    score_weighted, train_pred, y_pred = RF_predict(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest, RFE_model, p, j)

    #save all information of the model and results as CSV files
    output_path = result_path + r'\selected_feature_num_{}/test/all_performance'.format(p)
    create_folder(output_path)

    #save performance metrics
    score_weighted.to_csv(output_path + r'/{}_{}_result.csv'.format(j, RFE_model), index=True)

    #save classification confusion matrix on training set
    save_report(ytrain, train_pred, p, j, 'train', RFE_model, result_path)

    #save classification confusion matrix on testing set
    save_report(ytest, y_pred, p, j, 'test', RFE_model, result_path)


def RF_predict_and_save_union(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest, RFE_model, p, j, path, feature_num):

    #call RF_predict to get a optimized model and get the predict results and performance metrics
    score_weighted, train_pred, y_pred = RF_predict(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest)

    # save all information of the model and results as CSV files
    output_path = path + r'/RF/all_performance'
    create_folder(output_path)

    #save performance metrics
    score_weighted.to_csv(output_path + r'/{}_{}_RF_result.csv'.format(p, feature_num), index=True)
    
    #save classification confusion matrix on training set
    train_path = path + r'/RF'
    save_union_report(ytrain, train_pred, p, j, feature_num, 'train', 'RF', train_path)

    #save classification confusion matrix on testing set
    test_path = path + r'/RF'
    save_union_report(ytest, y_pred, p, j, feature_num, 'test', 'RF', test_path)

    return score_weighted


##########################################################################################################################################################

def XGB_predict(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest):
    print('-------------------------------------------------------Parameter optimization for XGB--------------------------------------------------')
    xgb_model=XGBClassifier(random_state=42)
    rdf, rdf_param = XGB_wange(rbf=xgb_model, n_splits=n_splits, x_train=rfe_xtrain_bing, y_train=ytrain)
    #print("the best parameters：")
    #print(rdf_param)

    # base_models=[lr_model]
    base_models = [rdf]

    # creat Lgb_stack, an object of Create_ensemble , then call predict function to get the predict results with the base_model
    Lgb_stack = Create_ensemble(n_splits = n_splits, base_models = base_models) # n_splits folds cross-validation
    train_pred, y_pred= Lgb_stack.predict(rfe_xtrain_bing,ytrain, rfe_xtest_bing) # get the predict results for training set and testing set, respectively

    labels = [1,2,3,4]
    y_test_1 = label_binarize(ytest, classes=labels)
    y_preds = label_binarize(y_pred, classes=labels)

    score_weighted = np.zeros((3, 13), dtype=object)
    #get the best parameters
    score_weighted[0, :4] = [rdf_param['n_estimators'], rdf_param['learning_rate'], rdf_param['max_depth'], ['']]

    # calculate the performance metrics
    metrics = {
        'accuracy': accuracy_score(ytest, y_pred),
        'precision_weighted': precision_score(ytest, y_pred, average='weighted'),
        'recall_weighted': recall_score(ytest, y_pred, average='weighted'),
        'F1_weighted': f1_score(ytest, y_pred, average='weighted'),
        'precision_macro': precision_score(ytest, y_pred, average='macro'),
        'recall_macro': recall_score(ytest, y_pred, average='macro'),
        'F1_macro': f1_score(ytest, y_pred, average='macro'),
        'balanced_accuracy': balanced_accuracy_score(ytest, y_pred),
        'matthews_corrcoef': matthews_corrcoef(ytest, y_pred),
        #'roc_auc': roc_auc_score(y_test_1, y_preds)
    } 

    score_weighted[0, 4:] = list(metrics.values())

    # change to DataFrame
    score_columns = ['n_estimators', 'learning_rate', 'max_depth', ''] + list(metrics.keys())
    score_weighted = pd.DataFrame(score_weighted, columns=score_columns)

    
    #print(classification_report(ytest, y_pred))
    #print(confusion_matrix(ytest, y_pred))
    #print('------------------------------------------------------------------------------------------')

    return score_weighted, train_pred, y_pred

def XGB_predict_and_save(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest, RFE_model, p, j, result_path):

    #call XGB_predict to get a optimized model and get the predict results and performance metrics
    score_weighted, train_pred, y_pred = XGB_predict(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest, RFE_model, p, j)
    
    # save all information of the model and results as CSV files
    output_path = result_path + r'\selected_feature_num_{}/test/all_performance'.format(p)
    create_folder(output_path)

    #save performance metrics
    score_weighted.to_csv(output_path + r'/{}_{}_result.csv'.format(j, RFE_model), index=True)

    #save classification confusion matrix on training set
    save_report(ytrain, train_pred, p, j, 'train', RFE_model, result_path)

    #save classification confusion matrix on testing set
    save_report(ytest, y_pred, p, j, 'test', RFE_model, result_path)


def XGB_predict_and_save_union(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest, RFE_model, p, j, path, feature_num):

    #call XGB_predict to get a optimized model and get the predict results and performance metrics
    score_weighted, train_pred, y_pred = XGB_predict(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest)

    # save all information of the model and results as CSV files
    output_path = path + r'/XGB/all_performance'
    create_folder(output_path)

    #save performance metrics
    score_weighted.to_csv(output_path + r'/{}_{}_result.csv'.format(j, RFE_model), index=True)

    #save classification confusion matrix on training set
    train_path = path + r'/XGB'
    save_union_report(ytrain, train_pred, p, j, feature_num, 'train', 'XGB', train_path)
 
    #save classification confusion matrix on testing set
    test_path = path + r'/XGB'
    save_union_report(ytest, y_pred, p, j, feature_num, 'test', 'XGB', test_path)

    return score_weighted

##########################################################################################################################################################

def SVM_predict(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest):
    print('-------------------------------------------------------Parameter optimization for SVM--------------------------------------------------')
    svm_models=SVC(random_state=42)
    rdf, rdf_param = SVM_wange(rbf=svm_models, n_splits=n_splits, x_train=rfe_xtrain_bing, y_train=ytrain)
    #print("the best parameters：")
    #print(rdf_param)

    # base_models=[lr_model]
    base_models = [rdf]

    # creat Lgb_stack, an object of Create_ensemble , then call predict function to get the predict results with the base_model
    Lgb_stack = Create_ensemble(n_splits = n_splits, base_models = base_models) # n_splits folds cross-validation
    train_pred, y_pred= Lgb_stack.predict(rfe_xtrain_bing,ytrain, rfe_xtest_bing) # get the predict results for training set and testing set, respectively


    labels = [1,2,3,4]
    y_test_1 = label_binarize(ytest, classes=labels)
    y_preds = label_binarize(y_pred, classes=labels)

    score_weighted = np.zeros((3, 13), dtype=object)
    #get the best parameters
    score_weighted[0, :4] = [rdf_param['kernel'], rdf_param['C'], [''], ['']]

    # calculate the performance metrics
    metrics = {
        'accuracy': accuracy_score(ytest, y_pred),
        'precision_weighted': precision_score(ytest, y_pred, average='weighted'),
        'recall_weighted': recall_score(ytest, y_pred, average='weighted'),
        'F1_weighted': f1_score(ytest, y_pred, average='weighted'),
        'precision_macro': precision_score(ytest, y_pred, average='macro'),
        'recall_macro': recall_score(ytest, y_pred, average='macro'),
        'F1_macro': f1_score(ytest, y_pred, average='macro'),
        'balanced_accuracy': balanced_accuracy_score(ytest, y_pred),
        'matthews_corrcoef': matthews_corrcoef(ytest, y_pred),
        #'roc_auc': roc_auc_score(y_test_1, y_preds)
    } 

    score_weighted[0, 4:] = list(metrics.values())

    # change to DataFrame
    score_columns = ['kernel', 'C', '', ''] + list(metrics.keys())
    score_weighted = pd.DataFrame(score_weighted, columns=score_columns)

    
    #print(classification_report(ytest, y_pred))
    #print(confusion_matrix(ytest, y_pred))
    #print('------------------------------------------------------------------------------------------')

    return score_weighted, train_pred, y_pred

def SVM_predict_and_save(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest, RFE_model, p, j, result_path):

    #call SVM_predict to get a optimized model and get the predict results and performance metrics
    score_weighted, train_pred, y_pred = SVM_predict(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest, RFE_model, p, j)

    # save all information of the model and results as CSV files
    output_path = result_path + r'\selected_feature_num_{}/test/all_performance'.format(p)
    create_folder(output_path)

    #save performance metrics
    score_weighted.to_csv(output_path + r'/{}_{}_result.csv'.format(j, RFE_model), index=True)

    #save classification confusion matrix on training set
    save_report(ytrain, train_pred, p, j, 'train', RFE_model, result_path)

    #save classification confusion matrix on testing set
    save_report(ytest, y_pred, p, j, 'test', RFE_model, result_path)


def SVM_predict_and_save_union(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest, RFE_model, p, j, path, feature_num):

    #call SVM_predict to get a optimized model and get the predict results and performance metrics
    score_weighted, train_pred, y_pred = SVM_predict(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest)

    # save all information of the model and results as CSV files
    output_path = path + r'/SVM/all_performance'
    create_folder(output_path)

    #save performance metrics
    score_weighted.to_csv(output_path + r'/{}_{}_result.csv'.format(j, RFE_model), index=True)

    #save classification confusion matrix on training set
    train_path = path + r'/SVM'
    save_union_report(ytrain, train_pred, p, j, feature_num, 'train', 'SVM', train_path)

    #save classification confusion matrix on testing set
    test_path = path + r'/SVM'
    save_union_report(ytest, y_pred, p, j, feature_num, 'test', 'SVM', test_path)

    return score_weighted



##########################################################################################################################################################

def LR_predict(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest):
    print('-------------------------------------------------------Parameter optimization for LR--------------------------------------------------')
    lr_models=LogisticRegression(random_state=42)
    rdf, rdf_param = LR_wange(rbf=lr_models, n_splits=n_splits, x_train=rfe_xtrain_bing, y_train=ytrain)
    #print("the best parameters：")
    #print(rdf_param)

    # base_models=[lr_model]
    base_models = [rdf]

    # creat Lgb_stack, an object of Create_ensemble , then call predict function to get the predict results with the base_model
    Lgb_stack = Create_ensemble(n_splits = n_splits, base_models = base_models) # n_splits folds cross-validation
    train_pred, y_pred= Lgb_stack.predict(rfe_xtrain_bing,ytrain, rfe_xtest_bing) # get the predict results for training set and testing set, respectively

    labels = [1,2,3,4]
    y_test_1 = label_binarize(ytest, classes=labels)
    y_preds = label_binarize(y_pred, classes=labels)

    score_weighted = np.zeros((3, 13), dtype=object)
    #get the best parameters
    score_weighted[0, :4] = [rdf_param['solver'], rdf_param['C'], [''], ['']]

    # calculate the performance metrics
    metrics = {
        'accuracy': accuracy_score(ytest, y_pred),
        'precision_weighted': precision_score(ytest, y_pred, average='weighted'),
        'recall_weighted': recall_score(ytest, y_pred, average='weighted'),
        'F1_weighted': f1_score(ytest, y_pred, average='weighted'),
        'precision_macro': precision_score(ytest, y_pred, average='macro'),
        'recall_macro': recall_score(ytest, y_pred, average='macro'),
        'F1_macro': f1_score(ytest, y_pred, average='macro'),
        'balanced_accuracy': balanced_accuracy_score(ytest, y_pred),
        'matthews_corrcoef': matthews_corrcoef(ytest, y_pred),
        #'roc_auc': roc_auc_score(y_test_1, y_preds)
    } 

    score_weighted[0, 4:] = list(metrics.values())

    # change to DataFrame
    score_columns = ['solver', 'C', '', ''] + list(metrics.keys())
    score_weighted = pd.DataFrame(score_weighted, columns=score_columns)

    
    #print(classification_report(ytest, y_pred))
    #print(confusion_matrix(ytest, y_pred))
    #print('------------------------------------------------------------------------------------------')

    return score_weighted, train_pred, y_pred

def LR_predict_and_save(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest, RFE_model, p, j, result_path):

    #call LR_predict to get a optimized model and get the predict results and performance metrics
    score_weighted, train_pred, y_pred = LR_predict(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest, RFE_model, p, j)

    # save all information of the model and results as CSV files
    output_path = result_path + r'\selected_feature_num_{}/test/all_performance'.format(p)
    create_folder(output_path)

    #save performance metrics
    score_weighted.to_csv(output_path + r'/{}_{}_result.csv'.format(j, RFE_model), index=True)

    #save classification confusion matrix on training set
    save_report(ytrain, train_pred, p, j, 'train', RFE_model, result_path)

    #save classification confusion matrix on testing set
    save_report(ytest, y_pred, p, j, 'test', RFE_model, result_path)


def LR_predict_and_save_union(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest, RFE_model, p, j, path, feature_num):

    #call LR_predict to get a optimized model and get the predict results and performance metrics
    score_weighted, train_pred, y_pred = LR_predict(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest)


    # save all information of the model and results as CSV files
    output_path = path + r'/LR/all_performance'
    create_folder(output_path)

    #save performance metrics
    score_weighted.to_csv(output_path + r'/{}_{}_result.csv'.format(j, RFE_model), index=True)

    #save classification confusion matrix on training set
    train_path = path + r'/LR'
    save_union_report(ytrain, train_pred, p, j, feature_num, 'train', 'LR', train_path)

    #save classification confusion matrix on testing set
    test_path = path + r'/LR'
    save_union_report(ytest, y_pred, p, j, feature_num, 'test', 'LR', train_path)

    return score_weighted


####################################################################################################################################

########################################################################################

#the classifiers in the first layer of Stacking were set to LR, SVM, RF and XGBoost, decision tree (DT) is used here as the classifier in the second layer of Stacking. 

########################################################################################

def ST_predict(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest, RFE_model, p, j, model_param):
    print('-------------------------------Parameter optimization for STACKING--------------------------------')
              
    #Stacking第一层当中分类器的设置

    RF_clf = RandomForestClassifier(n_estimators=int(model_param[0, 0]), min_samples_split=int(model_param[0, 1]),
                                min_samples_leaf=int(model_param[0, 2]), max_depth=int(model_param[0, 3]))
    LR_clf = LogisticRegression(solver=model_param[1, 0], C=model_param[1, 1])
    XGB_clf = XGBClassifier(n_estimators=model_param[2, 0], learning_rate=model_param[2, 1], max_depth=int(model_param[2, 2]))
    SVM_clf = SVC(kernel=model_param[3,0], C=model_param[3, 1])
    
  
    base_models = [LR_clf, XGB_clf, SVM_clf, RF_clf]   
         
    dt_model=DecisionTreeClassifier(random_state=42)
    best_sclf = StackingCVClassifier(classifiers=base_models, meta_classifier=dt_model,
                                     use_features_in_secondary=True,
                                     store_train_meta_features=True, cv=10, n_jobs=-1)
    best_sclf.fit(rfe_xtrain_bing, ytrain)
    
    train_pred = best_sclf.predict(rfe_xtrain_bing)
    y_pred = best_sclf.predict(rfe_xtest_bing)
   


    labels = [1,2,3,4]
    y_test_1 = label_binarize(ytest, classes=labels)
    y_preds = label_binarize(y_pred, classes=labels)

    score_weighted = np.zeros((3, 13), dtype=object)
    #get the best parameters
    score_weighted[0, :4] = ['LR', 'XGB', 'SVM', 'RF']

    # calculate the performance metrics
    metrics = {
        'accuracy': accuracy_score(ytest, y_pred),
        'precision_weighted': precision_score(ytest, y_pred, average='weighted'),
        'recall_weighted': recall_score(ytest, y_pred, average='weighted'),
        'F1_weighted': f1_score(ytest, y_pred, average='weighted'),
        'precision_macro': precision_score(ytest, y_pred, average='macro'),
        'recall_macro': recall_score(ytest, y_pred, average='macro'),
        'F1_macro': f1_score(ytest, y_pred, average='macro'),
        'balanced_accuracy': balanced_accuracy_score(ytest, y_pred),
        'matthews_corrcoef': matthews_corrcoef(ytest, y_pred),
        #'roc_auc': roc_auc_score(y_test_1, y_preds)
    } 

    score_weighted[0, 4:] = list(metrics.values())

    # change to DataFrame
    score_columns = ['', '', '', ''] + list(metrics.keys())
    score_weighted = pd.DataFrame(score_weighted, columns=score_columns)

    
    #print(classification_report(ytest, y_pred))
    #print(confusion_matrix(ytest, y_pred))
    #print('------------------------------------------------------------------------------------------')


    return score_weighted, train_pred, y_pred



def ST_predict_and_save(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest, RFE_model, p, j, result_path):

    #call ST_predict to get a optimized model and get the predict results and performance metrics
    score_weighted, train_pred, y_pred = ST_predict(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest, RFE_model, p, j)

    # save all information of the model and results as CSV files
    output_path = result_path + r'\selected_feature_num_{}/test/all_performance'.format(p)
    create_folder(output_path)

    #save performance metrics
    score_weighted.to_csv(output_path + r'/{}_{}_result.csv'.format(j, RFE_model), index=True)

    #save classification confusion matrix on training set
    save_report(ytrain, train_pred, p, j, 'train', RFE_model, result_path)

    #save classification confusion matrix on testing set
    save_report(ytest, y_pred, p, j, 'test', RFE_model, result_path)

def ST_predict_and_save_union(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest, RFE_model, p, j, path, feature_num, model_param):

    #call LR_predict to get a optimized model and get the predict results and performance metrics
    score_weighted, train_pred, y_pred = ST_predict(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest, RFE_model, p, j, model_param)


    # save all information of the model and results as CSV files
    output_path = path + r'/ST/all_performance'
    create_folder(output_path)

    #save performance metrics
    score_weighted.to_csv(output_path + r'/{}_{}_result.csv'.format(j, RFE_model), index=True)

    #save classification confusion matrix on training set
    train_path = path + r'/ST'
    save_union_report(ytrain, train_pred, p, j, feature_num, 'train', 'ST', train_path)

    #save classification confusion matrix on testing set
    test_path = path + r'/ST'
    save_union_report(ytest, y_pred, p, j, feature_num, 'test', 'ST', train_path)

    return score_weighted

