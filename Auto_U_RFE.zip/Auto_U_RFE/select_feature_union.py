from config import *
warnings.filterwarnings('ignore')


class Select_feature_bing(object):    
    def __init__(self, n_splits, base_models):
        self.n_splits = n_splits
        self.base_models = base_models
    def predict(self, X, y):
        feature_name=X.columns
        X = np.array(X)
        y = np.array(y)
        folds = list(StratifiedKFold(n_splits=self.n_splits, shuffle=True,random_state=random_state).split(X, y))
        e=0
        for i, clf in enumerate(self.base_models):
            for j, (train_idx, valid_idx) in enumerate(folds):
                X_train = X[train_idx]
                Y_train = y[train_idx]
                X_train=pd.DataFrame(X_train)
                X_train.columns=feature_name
                ref = clf.fit(X_train, Y_train)
                all_name4 = X_train.columns.values.tolist()
                select_name_index4 = ref.get_support(indices=True)
                select_name4 = []
                for t in select_name_index4:
                    select_name4.append(all_name4[t])
                same_feature_xtrain = pd.DataFrame(X_train, columns=select_name4)
                if e==0:
                    selected_feature=same_feature_xtrain
                    e=e+1
                else:
                    selected_feature = pd.concat([selected_feature,same_feature_xtrain], axis=0,join='outer')   
                    selected_feature_bingji= pd.DataFrame(X_train, columns=selected_feature.columns)
        return selected_feature_bingji.columns