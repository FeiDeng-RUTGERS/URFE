#%%
from config import *
from select_union_single_model import *
from optimized_data_processing import feature, label
#from data_process import feature, label
warnings.filterwarnings('ignore')
from save_report import save_info
from Select_intersection import prepare_for_URFE, select_intersection, URFE
from predict import *


#bing means union
#weidu means dimensions
#wangge means grid



#select features by RFE

final_score_weighted = np.zeros((record_num, 18), dtype=object)


column_names = ['TFN', 'NFUF', 'NFA', 'repeat_times', 'classifier_name', 'model_param1','model_param2','model_param3','model_param4','accuracy', 'precision_weighted', 'recall_weighted', 'F1_weighted', 'precision_macro',  'recall_macro', 'F1_macro', 'balanced_accuracy', 'matthews_corrcoef']

final_score_weighted_df = pd.DataFrame(final_score_weighted, columns=column_names)


def save_final_score(final_score, index, p, feature_num, n, j, classifier_name, score_weighted):
    final_score.loc[index, :] = [p, feature_num, n, j, classifier_name] + list(score_weighted.iloc[0, :])
    return index + 1

def filter_and_sort(df, tfn_value):
    filtered = df[(df['TFN'] == tfn_value) & (df['accuracy'] > accuracy_expect)]
    return filtered.sort_values(by=['F1_weighted', 'recall_weighted', 'precision_weighted'], ascending=False)

# Used to store the final filtered model parameters
combined_result = pd.DataFrame(columns=column_names)

# Used to save index after each call to save_final_score
score_index = 0



for p in selected: #p is the base target feature number       
    for j in range(1, cycles+1):  #repeat times
        # print("""
        #       *************************the current target feature number is {}, repeat {} times*****************************
        #       """.format(p, j))

        # # import pre-processed data by feature and label
        xtrain,xtest,ytrain,ytest=train_test_split(feature,label,test_size=0.1,stratify=label,random_state=random_state) #split the data into training set and testing set according to 9:1

        # # Select features with a base estimator according the parameter of RFE_models in config file.
        for RFE_model in RFE_models:
            if RFE_model == 'LR':
                #print("LR as the base estimator in RFE")
                #use the function of selected_bing_feature_LR in select_union_single_model.py to train the modeland save results, return the selected feature names in subset 1.
                train_selected_feature_name = selected_bing_feature_LR(xtrain,ytrain,p)     
                
            if RFE_model == 'SVM':
                #print("SVM as the base estimator in RFE")
                #use the function of selected_bing_feature_SVM in select_union_single_model.py to train the modeland save results, return the selected feature names in subset 2.
                train_selected_feature_name = selected_bing_feature_SVM(xtrain, ytrain, p)   

            if RFE_model == 'RF':
                #print("RF as the base estimator in RFE")
                #use the function of selected_bing_feature_RF in select_union_single_model.py to train the modeland save results, return the selected feature names in subset 3.
                train_selected_feature_name = selected_bing_feature_RF(xtrain, ytrain, p)     

            rfe_xtrain_bing = pd.DataFrame(xtrain, columns=train_selected_feature_name)    #according to the p selected features to rebuild training set
            rfe_xtest_bing = pd.DataFrame(xtest, columns=train_selected_feature_name)      #according to the p selected features to rebuild testing set
            #print("the dimension of selected features")
            #print(rfe_xtrain_bing.shape)
            #print(train_selected_feature_name)

            # save selected features' information in specific file with the function of save_info in save_report.py
            save_info(p, j, RFE_model, train_selected_feature_name, result_path) 
            
            # use RF to predict the result for testing set according to the selected features in subset
            RF_predict_and_save(rfe_xtrain_bing, rfe_xtest_bing, ytrain, ytest, RFE_model, p, j, result_path) 

        #get the union and intersection feature sets with the select_intersection function in Select_intersection.py, 
        #based on three subsets (the target feature number is p, the repeat times is j) 
        #save them as csv files and return the set names, respectively.
    
        bing_name, jiao_name = select_intersection(p, j) #save the union set and the intersection set         

        bing_name = pd.Index(bing_name.index) 
        jiao_name = pd.Index(jiao_name.index)

        ######################################################################################
        model = RandomForestClassifier(random_state=random_state)

        ###########predict based on the union set############
        bingji_xtrain = pd.DataFrame(xtrain, columns=bing_name)
        bingji_xtest = pd.DataFrame(xtest, columns=bing_name)
        #print("the dimension of the union set")
        #print(bingji_xtrain.shape)
        #print(bing_name) 

        RF_predict_and_save(bingji_xtrain, bingji_xtest, ytrain, ytest, model, p, j, predict_bing_path)

        ###########predict based on the intersection set###########
        jiaoji_xtrain = pd.DataFrame(xtrain, columns=jiao_name)
        jiaoji_xtest = pd.DataFrame(xtest, columns=jiao_name)
        #print("the dimension of the intersection set")
        #print(jiaoji_xtrain.shape)
        #print(jiao_name) 

        if jiaoji_xtrain.shape == 0:
            print("the feature number of the intersection set is 0, cannot predict") # no feature in the intersection set
            continue

        RF_predict_and_save(jiaoji_xtrain, jiaoji_xtest, ytrain, ytest, model, p, j, predict_jiao_path) 


    ########################## Continuously expand the original intersection set based on feature ranking to rebuild finall_union_features ############################   
    base_features, ready_union_features = prepare_for_URFE(p)
    base_features = pd.Index(base_features.index)
    maxlength = len(ready_union_features)
    for n in range(1, maxlength+1): 
        # to expand the intersection set based on feature ranking with the function URFE in Select_intersection.py, the rebuild feature set saved in finall_union_features
        # On the basis of the intersection set, the first n features are added in sequence to form a new union feature set.

        finall_union_features = URFE(base_features, ready_union_features, n)

        finall_union_features = pd.Index(finall_union_features['score_selected_feature_name'])
        
        finall_union_xtrain = pd.DataFrame(xtrain, columns=finall_union_features)
        finall_union_xtest = pd.DataFrame(xtest, columns=finall_union_features)
        #print("{} features are currently added, and the dimension of the new set is".format(n))
        #print(finall_union_xtest.shape)
        #print(finall_union_xtest) 

        finall_union_path = finall_union_results_path + r'\selected_feature_num_{}\add_{}_to_{}'.format(p, n, len(base_features))
        create_folder(finall_union_path)
        finall_union_features.to_frame().to_csv(finall_union_path + r'\finall_union_feature_names.csv')
        
        feature_num = len(base_features) + n #current number of features

        temp_model_param =np.zeros((4, 4), dtype=object)        
        
        # to predict and save the result based on current union feature set with different classifiers respectively

        current_score_weighted = RF_predict_and_save_union(finall_union_xtrain, finall_union_xtest, ytrain, ytest, RFE_model, p, j, finall_union_path, feature_num) 
        score_index = save_final_score(final_score_weighted_df, score_index, p, feature_num, n, j, 'RF', current_score_weighted)
        temp_model_param[0,0:4] =list(current_score_weighted.iloc[0, 0:4])

        current_score_weighted = LR_predict_and_save_union(finall_union_xtrain, finall_union_xtest, ytrain, ytest, RFE_model, p, j, finall_union_path, feature_num) 
        score_index = save_final_score(final_score_weighted_df, score_index, p, feature_num, n, j, 'LR', current_score_weighted)
        temp_model_param[1,0:4] =list(current_score_weighted.iloc[0, 0:4])
        if temp_model_param[1,0]=='linear':
           temp_model_param[1,0]='liblinear'

        current_score_weighted = XGB_predict_and_save_union(finall_union_xtrain, finall_union_xtest, ytrain, ytest, RFE_model, p, j, finall_union_path, feature_num)
        score_index = save_final_score(final_score_weighted_df, score_index, p, feature_num, n, j, 'XGB', current_score_weighted)
        temp_model_param[2,0:4] =list(current_score_weighted.iloc[0, 0:4])

        current_score_weighted = SVM_predict_and_save_union(finall_union_xtrain, finall_union_xtest, ytrain, ytest, RFE_model, p, j, finall_union_path, feature_num)
        score_index = save_final_score(final_score_weighted_df, score_index, p, feature_num, n, j, 'SVM', current_score_weighted)
        temp_model_param[3,0:4] =list(current_score_weighted.iloc[0, 0:4])

        #stacking as the classifier
        current_score_weighted = ST_predict_and_save_union(finall_union_xtrain, finall_union_xtest, ytrain, ytest, RFE_model, p, j, finall_union_path, feature_num, temp_model_param)
        score_index = save_final_score(final_score_weighted_df, score_index, p, feature_num, n, j, 'ST', current_score_weighted)        




create_folder(output_path)
final_score_weighted_df.to_csv(output_path + r'/final_score_result.csv', index=True)

###
#We then first identify all models with an accuracy above 0.8 (the accuracy of models without feature selection was only about 0.6 to 0.7). Then a strategy of F1_weighted first, 
#Recall_weighted second, Precision_weighted third and MCC last was adopted to rank all models. 
###

# save sorted results
for p in selected:
    sorted_df = filter_and_sort(final_score_weighted_df, p)
    combined_result = pd.concat([combined_result, sorted_df])

###
#print(combined_result)
combined_result.to_csv(output_path + r'/final_combined_result.csv', index=True)

